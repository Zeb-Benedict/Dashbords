<?php
session_start();

const output_FILE = __DIR__ . '/output.json';


function loadoutputFromFile() {
    if (file_exists(output_FILE)) {
        $json = file_get_contents(output_FILE);
        $data = json_decode($json, true);
        if (is_array($data)) {
            return $data;
        }
    }
    return array_fill(0, 10, null);
}


function saveoutputToFile($output) {
    file_put_contents(output_FILE, json_encode($output, JSON_PRETTY_PRINT));
}


if (!isset($_SESSION['output'])) {
    $_SESSION['output'] = loadoutputFromFile();
}

$output = &$_SESSION['output'];


$firstName = trim($_POST['firstName'] ?? '');
$middleName = trim($_POST['middleName'] ?? '');
$lastName = trim($_POST['lastName'] ?? '');
$suffix = trim($_POST['suffix'] ?? '');
$contact = trim($_POST['contact'] ?? '');
$email = trim($_POST['email'] ?? '');
$technology = trim($_POST['technology'] ?? '');
$batch = trim($_POST['batch'] ?? '');
$idNumber = trim($_POST['idNumber'] ?? '');


$fullName = $firstName . ' ' . $middleName . ' ' . $lastName;
if ($suffix !== '') {
    $fullName .= ' ' . $suffix;
}


$index = array_search(null, $output, true);
if ($index === false) {
    $index = count($output);
    $output[] = null;
}


$output[$index] = [
    'name'       => htmlspecialchars($fullName, ENT_QUOTES),
    'contact'    => htmlspecialchars($contact, ENT_QUOTES),
    'email'      => htmlspecialchars($email, ENT_QUOTES),
    'technology' => htmlspecialchars($technology, ENT_QUOTES),
    'batch'      => htmlspecialchars($batch, ENT_QUOTES),
    'idNumber'   => htmlspecialchars($idNumber, ENT_QUOTES)
];


$_SESSION['output'] = $outputs;
saveoutputToFile($output);


header("Location: index.php?added=1");
exit;