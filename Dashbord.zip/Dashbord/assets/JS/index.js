const regForm = document.getElementById("regForm");
if (regForm) {
  regForm.addEventListener("submit", function (e) {
    if (!validateForm("reg")) {
      e.preventDefault();
      alert("Please correct the highlighted fields.");
    } else {
      setTimeout(() => regForm.reset(), 100);
      setTimeout(() => {
        const modal = document.getElementById("registerModal");
        if (modal) modal.style.display = "none";
      }, 200);
    }
  });
}


const editForm = document.getElementById("editForm");
if (editForm) {
  editForm.addEventListener("submit", function (e) {
    if (!validateForm("edit")) {
      e.preventDefault();
      alert("Please correct the highlighted area.");
    } else {
      setTimeout(() => {
        const modal = document.getElementById("editModal");
        if (modal) modal.style.display = "none";
      }, 200);
    }
  });
}


function validateForm(type) {
  let isValid = true;

  document
    .querySelectorAll(`#${type}Form input, #${type}Form select`)
    .forEach((input) => input.classList.remove("Not Valid!!!"));

  const firstName = document.getElementById("firstName");
  const middleName = document.getElementById("middleName");
  const lastName = document.getElementById("lastName");
  const suffix = document.getElementById("suffix");
  const contact = document.getElementById(
    type === "reg" ? "contact" : "editContact"
  );
  const email = document.getElementById(type === "reg" ? "email" : "editEmail");
  const batch = document.getElementById(type === "reg" ? "batch" : "editBatch");
  const technology = document.getElementById(
    type === "reg" ? "technology" : "editTechnology"
  );
  const idNumber = document.getElementById("idNumber");

  if (type === "reg") {
    const nameRegex = /^[A-Za-z]+$/;
    if (!nameRegex.test(firstName.value.trim())) {
      firstName.classList.add("Not Valid!!!");
      isValid = false;
    }
    if (!nameRegex.test(middleName.value.trim())) {
      middleName.classList.add("Not Valid!!!");
      isValid = false;
    }
    if (!nameRegex.test(lastName.value.trim())) {
      lastName.classList.add("Not Valid!!!");
      isValid = false;
    }
    const suffixRegex = /^[A-Za-z.]*$/;
    if (suffix.value.trim() !== "" && !suffixRegex.test(suffix.value.trim())) {
      suffix.classList.add("Not Valid!!!");
      isValid = false;
    }
  }

  if (!/^\d{10,15}$/.test(contact.value)) {
    contact.classList.add("Not Valid!!!");
    isValid = false;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
    email.classList.add("Not Valid!!!");
    isValid = false;
  }
  if (!/^\d+-[A-Z]+$/.test(batch.value)) {
    batch.classList.add("Not Valid!!!");
    isValid = false;
  }
  if (technology.value === "") {
    technology.classList.add("Not Valid!!!");
    isValid = false;
  }
  if (
    type === "reg" &&
    idNumber &&
    !/^\d{4}-\d{2}-\d{3}$/.test(idNumber.value)
  ) {
    idNumber.classList.add("Not Valid!!!");
    isValid = false;
  }

  return isValid;
}