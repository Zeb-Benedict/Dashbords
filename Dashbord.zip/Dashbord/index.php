<?php
session_start();

const PROFILE_FILE = __DIR__ . '/output.json';

function loadProfilesFromFile() {
    if (file_exists(PROFILE_FILE)) {
        $json = file_get_contents(PROFILE_FILE);
        $data = json_decode($json, true);
        if (is_array($data)) {
            return $data;
        }
    }
    return array_fill(0, 10, null);
}


function saveProfilesToFile($profiles) {
    file_put_contents(PROFILE_FILE, json_encode($profiles, JSON_PRETTY_PRINT));
}


if (!isset($_SESSION['profiles'])) {
    $_SESSION['profiles'] = loadProfilesFromFile();
}

$profiles = &$_SESSION['profiles'];
$success = '';
$errors = [];


if (isset($_GET['added']) && $_GET['added'] == '1') {
    $success = "New profile added successfully.";
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $index = isset($_POST['index']) ? intval($_POST['index']) : -1;

    if ($index >= 0 && $index < count($profiles)) {
        if ($action === 'delete') {
            $profiles[$index] = null;
            $success = "Profile deleted successfully.";
        } elseif ($action === 'edit') {
            $name = trim($_POST['name'] ?? '');
            $contact = trim($_POST['contact'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $technology = trim($_POST['technology'] ?? '');
            $batch = trim($_POST['batch'] ?? '');

            if (!$name || !$contact || !$email || !$technology || !$batch) {
                $errors[] = "All fields are required.";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Invalid email format.";
            } else {
                $profiles[$index] = [
                    'name'       => htmlspecialchars($name, ENT_QUOTES),
                    'contact'    => htmlspecialchars($contact, ENT_QUOTES),
                    'email'      => htmlspecialchars($email, ENT_QUOTES),
                    'technology' => htmlspecialchars($technology, ENT_QUOTES),
                    'batch'      => htmlspecialchars($batch, ENT_QUOTES),
                ];
                $success = "Profile updated successfully.";
            }
        }
        
        saveProfilesToFile($profiles);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard - Profiles</title>
  <link rel="stylesheet" href="assets/CSS/styles.css">
</head>
<body>

<?php if ($success): ?>
  <div class="message success"><?= $success ?></div>
<?php endif; ?>
<?php if ($errors): ?>
  <div class="message error">
    <ul>
      <?php foreach ($errors as $e): ?>
        <li><?= $e ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="top-bar">
  <button class="btn-primary" onclick="openRegisterModal()">Register User</button>
</div>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>Contact</th>
      <th>Email</th>
      <th>Technology</th>
      <th>Batch</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($profiles as $i => $profile): ?>
      <?php if ($profile): ?>
        <tr>
          <td><?= $profile['name'] ?></td>
          <td><?= $profile['contact'] ?></td>
          <td><?= $profile['email'] ?></td>
          <td><?= $profile['technology'] ?></td>
          <td><?= $profile['batch'] ?></td>
          <td class="actions">
            <button class="edit" onclick='openEditModal(<?= $i ?>, <?= json_encode($profile) ?>)'>Edit</button>
            <form method="post" style="display:inline;">
              <input type="hidden" name="index" value="<?= $i ?>">
              <input type="hidden" name="action" value="delete">
              <button type="submit" class="delete" onclick="return confirm('Delete this profile?');">Delete</button>
            </form>
          </td>
        </tr>
      <?php endif; ?>
    <?php endforeach; ?>
  </tbody>
</table>


<div class="modal" id="registerModal">
  <div class="modal-content">
    <span class="close-btn" onclick="closeModal('registerModal')">&times;</span>
    <h2>Register User</h2>
    <form action="process.php" method="post" id="regForm">
      <div class="form-group">
        <label for="firstName">First Name</label>
        <input type="text" id="firstName" name="firstName" required />
      </div>
      <div class="form-group">
        <label for="middleName">Middle Name</label>
        <input type="text" id="middleName" name="middleName" required />
      </div>
      <div class="form-group">
        <label for="lastName">Last Name</label>
        <input type="text" id="lastName" name="lastName" required />
      </div>
      <div class="form-group">
        <label for="suffix">Suffix (Optional)</label>
        <input type="text" id="suffix" name="suffix" />
      </div>
      <div class="form-group">
        <label for="contact">Contact</label>
        <input type="text" id="contact" name="contact" required />
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required />
      </div>
      <div class="form-group">
        <label for="batch">Batch (EX: 33-G)</label>
        <input type="text" id="batch" name="batch" required />
      </div>
      <div class="form-group">
        <label for="technology">Technology</label>
        <select id="technology" name="technology" required>
          <option value="">-- Select Technology --</option>
          <option value="Computer">Computer</option>
          <option value="Electrical">Electrical</option>
          <option value="Mechanical">Mechanical</option>
          <option value="Electronics">Electronics</option>
        </select>
      </div>
      <div class="form-group">
        <label for="idNumber">ID Number (EX:2023-33-295)</label>
        <input type="text" id="idNumber" name="idNumber" required />
      </div>
      <button type="submit" class="btn">Register</button>
    </form>
  </div>
</div>


<div class="modal" id="editModal">
  <div class="modal-content">
    <span class="close-btn" onclick="closeModal('editModal')">&times;</span>
    <h2>Edit Profile</h2>
    <form method="post" id="editForm">
      <input type="hidden" name="index" id="editIndex" />
      <input type="hidden" name="action" value="edit" />
      <div class="form-group">
        <label>Name</label>
        <input type="text" id="editName" name="name" required />
      </div>
      <div class="form-group">
        <label>Contact</label>
        <input type="text" id="editContact" name="contact" required />
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" id="editEmail" name="email" required />
      </div>
      <div class="form-group">
        <label>Technology</label>
        <input type="text" id="editTechnology" name="technology" required />
      </div>
      <div class="form-group">
        <label>Batch</label>
        <input type="text" id="editBatch" name="batch" required />
      </div>
      <button type="submit" class="btn">Save Changes</button>
    </form>
  </div>
</div>

<script src="assets/JS/script.js"></script>
<script>
  function openRegisterModal() {
    document.getElementById('registerModal').style.display = 'flex';
  }
  function openEditModal(index, profile) {
    document.getElementById('editIndex').value = index;
    document.getElementById('editName').value = profile.name;
    document.getElementById('editContact').value = profile.contact;
    document.getElementById('editEmail').value = profile.email;
    document.getElementById('editTechnology').value = profile.technology;
    document.getElementById('editBatch').value = profile.batch;
    document.getElementById('editModal').style.display = 'flex';
  }
  function closeModal(id) {
    document.getElementById(id).style.display = 'none';
  }
</script>
</body>
</html>